package co.edu.unbosque.model;

public class ClaseY {
	
	public ClaseY() {
		
	}
	
	/* metodo que realiza un proceso basado en un par�metro "dato" 
	 * y retorne el dato procesado en esta claseY. Reemplazar por lo que se necesiten
	 */
	public String procesarDatoClaseY(String dato) {
		return dato+" Procesado por Clase Y";
	}
}
